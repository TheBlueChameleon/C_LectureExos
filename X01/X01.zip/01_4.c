#include <stdio.h>

int main (void) {
  int x = 209;
  
  printf("Zahl         : %f\n", x     );
  printf("letzte Ziffer: %f\n", x % 10);
}
